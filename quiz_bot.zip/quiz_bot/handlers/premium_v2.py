from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from keyboards.app_keyboards import premium_keyboard
from services.payment_service_db import payment_service
from services.premium_service_db import premium_service
from services.user_service_db import user_service
from utils.formatters import format_premium_text


async def premium_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = user_service.ensure_user(update.effective_user)
    await update.effective_message.reply_text(payment_service.premium_status_text(user))


async def subscribe_premium_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user = user_service.ensure_user(query.from_user)
    data = query.data

    if data == "premium:view":
        quiz_access_text = "All quiz sets" if premium_service.is_premium(user["user_id"]) else "Unlocked sets only"
        if premium_service.is_premium(user["user_id"]):
            pdf_text = "Unlimited"
        else:
            pdf_text = "1" if user_service.can_generate_free_pdf(user) else "0"
        await query.message.reply_text(
            format_premium_text(
                premium_service.status_text(user),
                quiz_access_text,
                pdf_text,
                0,
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=premium_keyboard(),
        )
        return

    if data in {"premium:subscribe", "premium:coming_soon"}:
        await query.message.reply_text(
            (
                "<b>💎 Premium Plans</b>\n\n"
                "Payment system under testing.\n"
                "Premium checkout will be enabled after deployment validation.\n\n"
                "Your quiz flow, timer, admin panel, and scheduled notifications are ready to use."
            ),
            parse_mode=ParseMode.HTML,
        )
        return

    if data.startswith("premium:plan:"):
        await query.message.reply_text(
            (
                "<b>💎 Premium Plans</b>\n\n"
                "Payment system under testing.\n"
                "Checkout is temporarily disabled for users."
            ),
            parse_mode=ParseMode.HTML,
        )
        return

import html
import hashlib
import json

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

from config import PUBLIC_BASE_URL, RAZORPAY_KEY_ID
from services.payment_service_db import SUBSCRIPTION_PLANS, payment_service
from utils.logging_utils import get_logger


logger = get_logger(__name__)

app = FastAPI(title="Quiz Bot Webhook Server")


def _render_status_page(
    *,
    title: str,
    message: str,
    detail: str,
    status_kind: str,
) -> HTMLResponse:
    palette = {
        "success": ("#15803d", "Verified"),
        "failure": ("#b91c1c", "Not Verified"),
        "pending": ("#b45309", "Pending Verification"),
    }
    accent, badge = palette.get(status_kind, palette["failure"])
    return HTMLResponse(
        f"""
        <!doctype html>
        <html>
        <head>
          <meta charset="utf-8" />
          <title>{html.escape(title)}</title>
        </head>
        <body style="font-family: Arial, sans-serif; max-width: 640px; margin: 48px auto; padding: 0 16px;">
          <div style="border: 1px solid #e5e7eb; border-radius: 16px; padding: 24px;">
            <div style="display: inline-block; padding: 6px 10px; border-radius: 999px; background: #f3f4f6; color: {accent}; font-weight: 700;">
              {badge}
            </div>
            <h2 style="margin-top: 16px; color: {accent};">{html.escape(title)}</h2>
            <p style="font-size: 16px; line-height: 1.6;">{html.escape(message)}</p>
            <p style="color: #4b5563; line-height: 1.6;">{html.escape(detail)}</p>
          </div>
        </body>
        </html>
        """
    )


@app.get("/health", response_class=PlainTextResponse)
async def health():
    return "OK"


@app.get("/pay/{order_id}", response_class=HTMLResponse)
async def payment_page(order_id: str):
    logger.info("Payment page opened | order_id=%s", order_id)
    order = payment_service.get_order(order_id)
    if not order:
        logger.warning("Payment page open failed | order_id=%s reason=order_not_found", order_id)
        return _render_status_page(
            title="Payment Details Not Found",
            message="We could not find this payment order.",
            detail="The payment may have expired, been cancelled, or the link may be invalid.",
            status_kind="failure",
        )

    plan_name = SUBSCRIPTION_PLANS.get(order["plan_type"], {}).get("name", "Payment")
    amount_rupees = order["amount"] / 100
    checkout_options = {
        "amount": order["amount"],
        "currency": order["currency"],
        "name": "Quiz Bot Premium",
        "description": plan_name,
        "order_id": order_id,
        "notes": {
            "user_id": str(order["user_id"]),
            "plan_type": str(order["plan_type"]),
        },
        "theme": {"color": "#0f766e"},
        "retry": {"enabled": True},
    }
    logger.info("Checkout options prepared | order_id=%s options=%s", order_id, checkout_options)
    checkout_options_json = json.dumps(
        {
            "key": RAZORPAY_KEY_ID,
            **checkout_options,
        }
    )

    return HTMLResponse(
        f"""
        <!doctype html>
        <html>
        <head>
          <meta charset="utf-8" />
          <title>Quiz Bot Premium Payment</title>
          <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        </head>
        <body style="font-family: Arial, sans-serif; max-width: 560px; margin: 40px auto;">
          <h2>💎 Quiz Bot Premium</h2>
          <p><b>Plan:</b> {html.escape(plan_name)}</p>
          <p><b>Amount:</b> INR {amount_rupees:.2f}</p>
          <p style="color: #4b5563;">Secure checkout is handled entirely by Razorpay. Available UPI and payment methods come directly from Razorpay.</p>
          <button id="pay-btn" style="padding: 12px 20px; font-size: 16px;">Pay with Razorpay</button>
          <script>
            const successUrl = "{PUBLIC_BASE_URL}/payment/success";
            const cancelUrl = "{PUBLIC_BASE_URL}/payment/cancel?razorpay_order_id={order_id}";
            const failureUrlBase = "{PUBLIC_BASE_URL}/payment/failed?razorpay_order_id={order_id}";
            const options = {checkout_options_json};
            options.redirect = false;
            options.handler = function (response) {{
              console.log("Payment success response:", response);

              const form = document.createElement("form");
              form.method = "POST";
              form.action = successUrl;

              for (const key in response) {{
                const input = document.createElement("input");
                input.type = "hidden";
                input.name = key;
                input.value = response[key];
                form.appendChild(input);
              }}

              document.body.appendChild(form);
              form.submit();
            }};
            options.modal = {{
              ondismiss: function () {{
                alert("Payment cancelled ❌");
                window.location.href = cancelUrl;
              }}
            }};

            const rzp = new Razorpay(options);
            rzp.on("payment.failed", function (response) {{
              const reason = encodeURIComponent(
                response.error && (response.error.description || response.error.reason || response.error.code) || "payment_failed"
              );
              window.location.href = failureUrlBase + "&reason=" + reason;
            }});
            document.getElementById("pay-btn").onclick = function (e) {{
              rzp.open();
              e.preventDefault();
            }};
          </script>
        </body>
        </html>
        """
    )


@app.get("/payment/cancel", response_class=HTMLResponse)
async def payment_cancel(razorpay_order_id: str | None = None):
    if razorpay_order_id:
        payment_service.update_order_status(razorpay_order_id, "cancelled")
    logger.info("Payment cancelled | order_id=%s", razorpay_order_id)
    return _render_status_page(
        title="Payment Cancelled",
        message="The payment was cancelled before completion.",
        detail="You can close this page and try again from the bot whenever you are ready.",
        status_kind="failure",
    )


@app.get("/payment/failed", response_class=HTMLResponse)
async def payment_failed(
    razorpay_order_id: str | None = None,
    reason: str | None = None,
):
    if razorpay_order_id:
        payment_service.update_order_status(razorpay_order_id, "failed")
    logger.warning("Payment failed | order_id=%s reason=%s", razorpay_order_id, reason)
    return _render_status_page(
        title="Payment Not Completed",
        message="Payment not completed or verification failed.",
        detail=reason or "The payment app reported a failure before verification could complete.",
        status_kind="failure",
    )


@app.api_route("/payment/success", methods=["GET", "POST"], response_class=HTMLResponse)
async def payment_success(request: Request):
    form_data = {}
    if request.method == "POST":
        try:
            form_data = dict(await request.form())
        except Exception:
            form_data = {}

    query_data = dict(request.query_params)
    logger.info(
        "Payment callback params received | method=%s form_keys=%s query_keys=%s",
        request.method,
        sorted(form_data.keys()),
        sorted(query_data.keys()),
    )

    params = {
        "razorpay_payment_id": form_data.get("razorpay_payment_id") or query_data.get("razorpay_payment_id"),
        "razorpay_order_id": form_data.get("razorpay_order_id") or query_data.get("razorpay_order_id"),
        "razorpay_signature": form_data.get("razorpay_signature") or query_data.get("razorpay_signature"),
    }

    payment_id = params["razorpay_payment_id"]
    order_id = params["razorpay_order_id"]
    signature = params["razorpay_signature"]

    logger.info(
        "Payment callback received | order_id=%s payment_id=%s method=%s",
        order_id,
        payment_id,
        request.method,
    )

    if not payment_id or not order_id or not signature:
        if order_id:
            payment_service.update_order_status(order_id, "callback_incomplete")
        logger.warning(
            "Payment callback failed | order_id=%s reason=missing_fields payment_id=%s signature_present=%s",
            order_id,
            payment_id,
            bool(signature),
        )
        return _render_status_page(
            title="Payment Not Completed",
            message="Payment not completed or verification failed.",
            detail="The payment may have been cancelled, abandoned, or returned without the required Razorpay verification details.",
            status_kind="failure",
        )

    order = payment_service.get_order(order_id)
    if not order:
        logger.warning("Payment callback failed | order_id=%s reason=order_not_found", order_id)
        return _render_status_page(
            title="Payment Details Not Found",
            message="Payment not completed or verification failed.",
            detail="We could not match this callback to a saved order.",
            status_kind="failure",
        )

    signature_ok = payment_service.verify_payment_signature(
        order_id=order_id,
        payment_id=payment_id,
        signature=signature,
    )
    if not signature_ok:
        payment_service.update_order_status(order_id, "callback_verification_failed")
        logger.warning(
            "Payment callback signature failed | order_id=%s payment_id=%s reason=signature_mismatch",
            order_id,
            payment_id,
        )
        return _render_status_page(
            title="Payment Verification Failed",
            message="Payment not completed or verification failed.",
            detail="Razorpay returned callback details, but the signature did not verify. Premium has not been activated.",
            status_kind="failure",
        )

    payment_service.update_order_status(order_id, "callback_verified")
    logger.info(
        "Payment callback signature verified | order_id=%s payment_id=%s",
        order_id,
        payment_id,
    )
    return _render_status_page(
        title="Payment Verification Received",
        message="Your payment details were received and verified.",
        detail="Premium will be activated only after Razorpay sends a valid payment.captured webhook confirmation.",
        status_kind="pending",
    )


@app.post("/webhook/razorpay")
async def razorpay_webhook(
    request: Request,
    x_razorpay_signature: str | None = Header(default=None),
    x_razorpay_event_id: str | None = Header(default=None),
):
    logger.info("Webhook received | event_id=%s", x_razorpay_event_id)

    raw_body = await request.body()
    if not x_razorpay_signature:
        logger.warning("Webhook rejected | event_id=%s reason=missing_signature", x_razorpay_event_id)
        raise HTTPException(status_code=400, detail="Missing Razorpay signature")

    signature_ok = payment_service.verify_webhook_signature(raw_body, x_razorpay_signature)
    if not signature_ok:
        logger.warning("Webhook signature failed | event_id=%s", x_razorpay_event_id)
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    logger.info("Webhook signature verified | event_id=%s", x_razorpay_event_id)
    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        logger.warning("Webhook rejected | event_id=%s reason=invalid_json", x_razorpay_event_id)
        raise HTTPException(status_code=400, detail="Invalid webhook payload") from exc

    event_name = payload.get("event")
    logger.info("Webhook event type | event_id=%s event=%s", x_razorpay_event_id, event_name)
    if event_name != "payment.captured":
        logger.info("Webhook ignored | event_id=%s event=%s", x_razorpay_event_id, event_name)
        return JSONResponse({"status": "ignored", "reason": "unsupported_event"})

    derived_event_id = (
        x_razorpay_event_id
        or payload.get("payload", {}).get("payment", {}).get("entity", {}).get("id")
        or hashlib.sha256(raw_body).hexdigest()
    )
    try:
        result = payment_service.process_captured_payment(derived_event_id, payload)
    except ValueError as exc:
        logger.warning("Webhook processing failed | event_id=%s reason=%s", derived_event_id, exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Webhook processing crashed | event_id=%s", derived_event_id)
        raise HTTPException(status_code=500, detail=f"Webhook processing failed: {exc}") from exc

    if result.get("status") == "processed":
        logger.info(
            "Webhook processed successfully | event_id=%s user_id=%s plan_type=%s",
            derived_event_id,
            result.get("user_id"),
            result.get("plan_type"),
        )

    return JSONResponse(result)
